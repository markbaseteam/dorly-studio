### Profissional - 10 horas
50%
Entrevistar e vender para clientes
Fazer entregas para clientes (Workshops, palestras, mentoria, consultoria e coaching)

20%
Escrever artigos e playbooks
Escrever, gravar e editar podcast
Escrever, gravar e editar vídeos

20%
Desenvolver negócio e serviços
Controlar finanças da empresa

10%
Fazer networking com empreendedores

### Pessoal - 12 horas
70%
Se cuidar (marcar médicos, comer saudável, fazer exercício físico, meditar, dormir bem)

5%
Passear e treinar o cachorro

10%
Ajudar pais com a loja

15%
Desenvolver laços de amizadede


